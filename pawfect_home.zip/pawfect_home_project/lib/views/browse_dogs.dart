import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import '../services/mock_dogs.dart';
import '../widgets/dog_card.dart';
import 'dog_detail.dart';

class BrowseDogsView extends StatefulWidget {
  const BrowseDogsView({super.key});

  @override
  State<BrowseDogsView> createState() => _BrowseDogsViewState();
}

class _BrowseDogsViewState extends State<BrowseDogsView> {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isTablet = width >= 600;
    final isLarge = width >= 900;
    final gridCols = isLarge ? 4 : (isTablet ? 3 : 2);

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Text('🐾', style: TextStyle(fontSize: 28)),
                  const SizedBox(width: 8),
                  Text('Find Your Pawfect Friend', style: Theme.of(context).textTheme.titleLarge),
                ],
              ),
              const SizedBox(height: 12),

              // Activity #1: displays three Text widgets in a Row with equal spacing. (Home page)
              _Card(
                title: 'Adoption Steps',
                subtitle: 'A simple path to bringing a pet home',
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: const [
                      Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('Browse', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Color(0xFFEF8A49)))),
                      Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('Meet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Color(0xFF8EC5C2)))),
                      Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('Adopt', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Color(0xFF4CAF50)))),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Activity #2: Build a layout with two buttons in a Column, centered vertically and horizontally. (Home page)
              _Card(
                title: 'Quick Actions',
                subtitle: 'Get started with a tap',
                child: SizedBox(
                  height: isTablet ? 160 : 140,
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ConstrainedBox(
                          constraints: const BoxConstraints(minWidth: 160),
                          child: ElevatedButton.icon(
                            onPressed: () {},
                            icon: const Icon(Icons.pets),
                            label: const Text('Adopt Now'),
                          ),
                        ),
                        const SizedBox(height: 12),
                        ConstrainedBox(
                          constraints: const BoxConstraints(minWidth: 160),
                          child: OutlinedButton.icon(
                            onPressed: () {},
                            icon: const Icon(Icons.volunteer_activism),
                            label: const Text('Donate'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Activity #3: Use a Container to add padding, margin, and a background color around a Text widget. (Home page)
              _Card(
                title: 'Rescue Story',
                subtitle: 'Spotlight of the week',
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF3E8),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text('"I\'m Bella! I love cuddles and long walks. Help me find a forever home."'),
                ),
              ),
              const SizedBox(height: 24),

              Row(children: [const Text('🐶'), const SizedBox(width: 8), Text('Adoptable Dogs', style: Theme.of(context).textTheme.titleMedium)]),
              const SizedBox(height: 8),

              // Keep the existing grid as a reference/demo below the activities
              MasonryGridView.count(
                crossAxisCount: gridCols,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                itemCount: dogs.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final dog = dogs[index];
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DogDetailView(dog: dog),
                        ),
                      );
                    },
                    child: DogCard(dog: dog),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  const _Card({required this.title, required this.child, this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 2))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [const Icon(Icons.pets, color: Color(0xFFEF8A49)), const SizedBox(width: 8), Flexible(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis))]),
            if (subtitle != null) ...[
              const SizedBox(height: 4),
              Text(subtitle!, style: TextStyle(color: Colors.grey.shade600)),
            ],
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}
