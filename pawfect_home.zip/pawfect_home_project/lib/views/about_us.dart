import 'package:flutter/material.dart';
import '../widgets/custom_button.dart';

class AboutUsView extends StatelessWidget {
  const AboutUsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Text('🏡'), const SizedBox(width: 8), Text('About Pawfect Homes', style: Theme.of(context).textTheme.titleLarge)]),
          const SizedBox(height: 12),

          // Activity #5: Build a responsive layout using Expanded so that two containers share screen width in a Row. (About page)
          _Card(
            title: 'Capacity Overview',
            subtitle: 'Shelter vs Foster Homes',
            child: SizedBox(
              height: 90,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE3F2FD),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(child: Text('Shelter: 24/40')),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.only(left: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE8F5E9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(child: Text('Foster: 12/30')),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Activity #6: Design a navigation bar using Row with icons spaced evenly. (About page)
          _Card(
            title: 'Quick Navigation',
            subtitle: 'Rescue Shortcuts',
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                Icon(Icons.home),
                Icon(Icons.pets),
                Icon(Icons.favorite),
                Icon(Icons.chat),
              ],
            ),
          ),
          const SizedBox(height: 24),

          Center(child: Row(mainAxisSize: MainAxisSize.min, children: const [Text('🐾', style: TextStyle(fontSize:36)), SizedBox(width:8), Text('Pawfect Homes', style: TextStyle(fontSize:28, fontWeight: FontWeight.bold))])),
          const SizedBox(height: 16),
          const Text('🐾 Mission', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('To rescue, rehabilitate, and lovingly rehome dogs in need — ensuring each dog is given medical care, emotional support, and a safe forever family.'),
          const Divider(height: 28),
          const Text('🐾 Vision', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('A compassionate community where every dog is valued and protected, and where rescue and responsible ownership are the first choice.'),
          const Divider(height: 28),
          const Text('🐾 Campaigns', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const ListTile(leading: Text('🐾'), title: Text('Adopt, Don\'t Shop'), subtitle: Text('Encourage adoption and discourage buying from irresponsible sources.')),
          const ListTile(leading: Text('🐾'), title: Text('Paw for a Cause'), subtitle: Text('Community fundraisers and drives to support shelter care and medical needs.')),
          const ListTile(leading: Text('🐾'), title: Text('Educate to Rescue'), subtitle: Text('Programs teaching responsible pet ownership and the importance of spaying/neutering.')),
          const SizedBox(height: 12),
          Center(child: CustomButton(label: 'Join a Campaign', icon: Icons.volunteer_activism, onPressed: (){})),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  const _Card({required this.title, required this.child, this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 2))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [const Icon(Icons.pets, color: Color(0xFFEF8A49)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w700))]),
            if (subtitle != null) ...[
              const SizedBox(height: 4),
              Text(subtitle!, style: TextStyle(color: Colors.grey.shade600)),
            ],
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}
