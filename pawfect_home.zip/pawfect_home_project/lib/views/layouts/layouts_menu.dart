import 'package:flutter/material.dart';
import '../../models/dog.dart';
import '../layouts/row_three_status.dart';
import '../layouts/column_two_buttons.dart';
import '../layouts/padded_container_text.dart';
import '../layouts/profile_card.dart';
import '../layouts/expanded_row_compare.dart';
import '../layouts/nav_bar_row.dart';
import '../layouts/stack_pet_image.dart';
import '../layouts/flexible_column.dart';
import '../layouts/chat_bubble.dart';
import '../layouts/row_column_grid.dart';
import '../../services/mock_dogs.dart';

class LayoutsMenu extends StatelessWidget {
  const LayoutsMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pet Adoption UI')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: const [
              _SectionTitle('Showcase'),
              SizedBox(height: 12),

              // Activity #7: Create a Stack layout with a background image and a floating button overlay. (Layouts page)
              _Activity7(),
              SizedBox(height: 16),

              // Activity #8: Use Flexible inside a Column to resize widgets dynamically when screen orientation changes. (Layouts page)
              _Activity8(),
              SizedBox(height: 16),

              // Activity #10: Implement both Row and Column in the same widget tree to form a grid-like layout without using GridView. (Layouts page)
              _Activity10(),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('🐕'),
        const SizedBox(width: 8),
        Text(
          text,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

// Activity #7: Create a Stack layout with a background image and a floating button overlay. (Layouts page)
class _Activity7 extends StatelessWidget {
  const _Activity7();
  @override
  Widget build(BuildContext context) {
    final dog = dogs.first;
    return _Card(
      title: 'Featured Pup',
      subtitle: 'Meet ${dog.name}',
      child: SizedBox(
        height: 200,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.network(
                  dog.imageUrl,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [Colors.black.withValues(alpha: 0.5), Colors.transparent],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 12,
                bottom: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(dog.name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('${dog.breed} • ${dog.age} yrs', style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              Positioned(
                bottom: 12,
                right: 12,
                child: FloatingActionButton(
                  onPressed: () {},
                  child: const Icon(Icons.favorite),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Activity #8: Use Flexible inside a Column to resize widgets dynamically when screen orientation changes. (Layouts page)
class _Activity8 extends StatelessWidget {
  const _Activity8();
  @override
  Widget build(BuildContext context) {
    final dog = dogs.first;
    return _Card(
      title: 'Pet Details',
      subtitle: '${dog.name} • ${dog.breed}',
      child: Column(
        children: [
          Container(
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFFFF4E6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                const Icon(Icons.pets, color: Color(0xFFEF8A49)),
                const SizedBox(width: 8),
                Text('About ${dog.name}', style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFFE8F5E9),
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.all(12),
            child: Text(dog.description, maxLines: 3, overflow: TextOverflow.ellipsis),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFFE3F2FD),
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.all(12),
            child: const _RequirementsList(),
          ),
        ],
      ),
    );
  }
}

class _RequirementsList extends StatelessWidget {
  const _RequirementsList();
  @override
  Widget build(BuildContext context) {
    final items = const [
      'Secure, loving home environment',
      'Commitment to regular vet checkups',
      'Daily exercise and enrichment',
    ];
    return Wrap(
      runSpacing: 6,
      children: items
          .map((t) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.check_circle, color: Color(0xFF4CAF50), size: 18), const SizedBox(width: 8), Text(t)]),
              ))
          .toList(),
    );
  }
}

// Activity #10: Implement both Row and Column in the same widget tree to form a grid-like layout without using GridView. (Layouts page)
class _Activity10 extends StatelessWidget {
  const _Activity10();
  @override
  Widget build(BuildContext context) {
    return _Card(
      title: 'Adoption Center Map',
      subtitle: 'Sections A–B • Tap a kennel for details',
      child: Column(
        children: [
          Row(
            children: const [
              Expanded(child: _KennelCell(label: 'A1', status: KennelStatus.available)),
              SizedBox(width: 8),
              Expanded(child: _KennelCell(label: 'A2', status: KennelStatus.adopted)),
              SizedBox(width: 8),
              Expanded(child: _KennelCell(label: 'A3', status: KennelStatus.available)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: const [
              Expanded(child: _KennelCell(label: 'B1', status: KennelStatus.grooming)),
              SizedBox(width: 8),
              Expanded(child: _KennelCell(label: 'B2', status: KennelStatus.available)),
              SizedBox(width: 8),
              Expanded(child: _KennelCell(label: 'B3', status: KennelStatus.cleaning)),
            ],
          ),
        ],
      ),
    );
  }
}

enum KennelStatus { available, adopted, cleaning, grooming }

class _KennelCell extends StatelessWidget {
  final String label;
  final KennelStatus status;
  const _KennelCell({required this.label, required this.status});
  @override
  Widget build(BuildContext context) {
    final statusText = switch (status) {
      KennelStatus.available => 'Available',
      KennelStatus.adopted => 'Adopted',
      KennelStatus.cleaning => 'Cleaning',
      KennelStatus.grooming => 'Grooming',
    };
    final statusColor = switch (status) {
      KennelStatus.available => const Color(0xFF4CAF50),
      KennelStatus.adopted => const Color(0xFF9E9E9E),
      KennelStatus.cleaning => const Color(0xFFFFA000),
      KennelStatus.grooming => const Color(0xFF29B6F6),
    };
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.circle, size: 10, color: statusColor),
                  const SizedBox(width: 6),
                  Text(statusText, style: TextStyle(color: statusColor)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  const _Card({required this.title, required this.child, this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 2))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [const Icon(Icons.pets, color: Color(0xFFEF8A49)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w700))]),
            if (subtitle != null) ...[
              const SizedBox(height: 4),
              Text(subtitle!, style: TextStyle(color: Colors.grey.shade600)),
            ],
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}