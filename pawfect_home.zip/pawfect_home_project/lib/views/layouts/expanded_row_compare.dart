import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class ExpandedRowCompare extends StatelessWidget {
  const ExpandedRowCompare({super.key});

  @override
  Widget build(BuildContext context) {
    final left = dogs[0];
    final right = dogs.length>1? dogs[1] : dogs[0];
    return Row(
      children: [
        Expanded(
          child: Column(
            children: [
              Image.network(left.imageUrl, height:150, fit: BoxFit.cover),
              const SizedBox(height:8),
              Text(left.name, style: Theme.of(context).textTheme.titleMedium),
              Text(left.breed),
            ],
          ),
        ),
        const SizedBox(width:8),
        Expanded(
          child: Column(
            children: [
              Image.network(right.imageUrl, height:150, fit: BoxFit.cover),
              const SizedBox(height:8),
              Text(right.name, style: Theme.of(context).textTheme.titleMedium),
              Text(right.breed),
            ],
          ),
        ),
      ],
    );
  }
}