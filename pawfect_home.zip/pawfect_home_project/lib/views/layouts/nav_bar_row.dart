import 'package:flutter/material.dart';

class NavBarRow extends StatelessWidget {
  const NavBarRow({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton(onPressed: ()=> Navigator.popUntil(context, (r)=> r.isFirst), icon: const Icon(Icons.home)),
        IconButton(onPressed: ()=> Navigator.pushNamed(context, '/'), icon: const Icon(Icons.pets)),
        IconButton(onPressed: ()=> Navigator.pushNamed(context, '/'), icon: const Icon(Icons.person)),
        IconButton(onPressed: ()=> Navigator.pushNamed(context, '/'), icon: const Icon(Icons.settings)),
      ],
    );
  }
}