import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class FlexibleColumnLayout extends StatelessWidget {
  const FlexibleColumnLayout({super.key});

  @override
  Widget build(BuildContext context) {
    final dog = dogs.first;
    return OrientationBuilder(
      builder: (context, orientation){
        return Column(
          children: [
            Flexible(flex: 2, child: Image.network(dog.imageUrl, fit: BoxFit.cover, width: double.infinity)),
            Flexible(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(dog.name, style: Theme.of(context).textTheme.titleLarge),
                    Text(dog.breed),
                    const SizedBox(height:8),
                    Expanded(child: SingleChildScrollView(child: Text(dog.description))),
                  ],
                ),
              ),
            )
          ],
        );
      },
    );
  }
}