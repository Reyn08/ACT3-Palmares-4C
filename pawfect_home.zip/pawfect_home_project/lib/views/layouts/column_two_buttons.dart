import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class ColumnTwoButtons extends StatelessWidget {
  const ColumnTwoButtons({super.key});

  @override
  Widget build(BuildContext context) {
    final sample = dogs.first;
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton(
          onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> Scaffold(
            appBar: AppBar(title: const Text('Adopt Now')),
            body: const Center(child: Text('Adoption flow placeholder')),
          ))),
          child: const Text('Adopt Now'),
        ),
        const SizedBox(height:12),
        OutlinedButton(
          onPressed: ()=> showDialog(context: context, builder: (_)=> AlertDialog(
            title: const Text('Donate'),
            content: Text('Donate to support ${sample.name} and other rescue pets.'),
            actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('Close'))],
          )),
          child: const Text('Donate'),
        ),
      ],
    );
  }
}