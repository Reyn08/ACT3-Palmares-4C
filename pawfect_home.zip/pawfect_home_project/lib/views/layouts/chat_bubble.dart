import 'package:flutter/material.dart';

class ChatBubbleUI extends StatelessWidget {
  const ChatBubbleUI({super.key});

  Widget _bubble(String text, bool mine){
    return Align(
      alignment: mine? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical:6, horizontal:12),
        padding: const EdgeInsets.all(12),
        constraints: const BoxConstraints(maxWidth: 300),
        decoration: BoxDecoration(
          color: mine? null : Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(text),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _bubble('Hi, is Buddy still available?', false),
        _bubble('Yes! Buddy is available for adoption.', true),
        _bubble('How do I start the process?', false),
      ],
    );
  }
}