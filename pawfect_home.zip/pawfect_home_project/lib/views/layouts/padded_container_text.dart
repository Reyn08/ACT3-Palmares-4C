import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class PaddedContainerText extends StatelessWidget {
  const PaddedContainerText({super.key});

  @override
  Widget build(BuildContext context) {
    final story = dogs.first.rescueStory;
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(story, style: const TextStyle(fontSize:16)),
    );
  }
}