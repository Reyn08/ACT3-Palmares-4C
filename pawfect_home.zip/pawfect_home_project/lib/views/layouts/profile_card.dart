import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class ProfileCardLayout extends StatelessWidget {
  const ProfileCardLayout({super.key});

  @override
  Widget build(BuildContext context) {
    final dog = dogs.first;
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(dog.imageUrl, width:90, height:90, fit: BoxFit.cover),
            ),
            const SizedBox(width:12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(dog.name, style: Theme.of(context).textTheme.titleLarge),
                  Text(dog.breed),
                  const SizedBox(height:8),
                  Text('Age: ${dog.age} • Size: ${dog.size}'),
                  const SizedBox(height:8),
                  Text(dog.description, maxLines:3, overflow: TextOverflow.ellipsis),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}