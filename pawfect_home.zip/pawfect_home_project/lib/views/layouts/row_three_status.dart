import 'package:flutter/material.dart';
import '../../services/mock_dogs.dart';

class RowThreeStatus extends StatelessWidget {
  const RowThreeStatus({super.key});

  @override
  Widget build(BuildContext context) {
    // Purpose: show overall adoption counts/statuses for the app
    final available = dogs.where((d)=> d.name.isNotEmpty).length;
    final pending = 2; // sample
    final adopted = 1; // sample
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Column(children: [Text('Available', style: Theme.of(context).textTheme.bodyLarge), Text('$available')]),
        Column(children: [Text('Pending', style: Theme.of(context).textTheme.bodyLarge), Text('$pending')]),
        Column(children: [Text('Adopted', style: Theme.of(context).textTheme.bodyLarge), Text('$adopted')]),
      ],
    );
  }
}