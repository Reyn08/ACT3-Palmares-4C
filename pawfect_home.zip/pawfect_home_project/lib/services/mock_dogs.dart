import '../models/dog.dart';

final List<Dog> dogs = [
  Dog(
    name: "Buddy",
    breed: "Golden Retriever",
    age: "3 years",
    size: "Big",
    imageUrl:
        "https://www.borrowmydoggy.com/_next/image?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F4ij0poqn%2Fproduction%2Fda89d930fc320dd912a2a25487b9ca86b37fcdd6-800x600.jpg&w=1080&q=80",
    description:
        "Buddy is a warm-hearted Golden Retriever who greets everyone with a wagging tail and calm eyes. He loves fetch, swimming, and sitting by your feet while you read. Patient with children and gentle with strangers, Buddy learns quickly and thrives on daily exercise and cuddles.",
    rescueStory:
        "Found under a highway overpass, injured and hungry. Volunteers nursed him back to health; his resilience and warmth made him a shelter favorite.",
  ),
  Dog(
    name: "Luna",
    breed: "Shih Tzu",
    age: "2 years",
    size: "Small",
    imageUrl:
        "https://cdn.britannica.com/05/234205-050-F8D2E018/Shih-tzu-dog.jpg",
    description:
        "Luna is a tiny bundle of joy who adores soft blankets and gentle lap time. Playful during the day and a calm cuddle companion at night, she loves short walks and being pampered. Her shining personality melts the hearts of everyone she meets.",
    rescueStory:
        "Rescued from a small, forgotten cage in a hoarding situation; with tender care she blossomed into a loving companion.",
  ),
  Dog(
    name: "Rocky",
    breed: "German Shepherd",
    age: "4 years",
    size: "Big",
    imageUrl:
        "https://www.bellaandduke.com/wp-content/uploads/2024/10/A-guide-to-German-Shepherds-characteristics-personality-lifespan-and-more-featured-image-1024x683.webp",
    description:
        "Rocky is loyal, bright, and protective. He enjoys mental challenges, long walks, and games that stimulate his mind. Rocky bonds deeply with his people and shows a gentle side with family members. He flourishes with consistent training and a purpose.",
    rescueStory:
        "Surrendered when his family moved abroad; with training and patience he regained confidence and now seeks an experienced owner to lead him.",
  ),
  Dog(
    name: "Max",
    breed: "Beagle",
    age: "3 years",
    size: "Small",
    imageUrl:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKbK-tMuHT7InwJcuEyA9PV3a0GTqG-Ul52AXdT_-rxCNR9TrwkBiNapKpmK-9hSpdylA&usqp=CAU",
    description:
        "Max is curious and playful, always eager to follow an interesting scent. He loves toys, exploring, and making new friends. His cheerful spirit is infectious and he settles gracefully after a day of adventures.",
    rescueStory:
        "Found roaming near farmlands and enticed by food; shelter volunteers socialized him and discovered his loving nature.",
  ),
  Dog(
    name: "Bantay",
    breed: "Aspin",
    age: "5 years",
    size: "Medium",
    imageUrl:
        "https://www.petexpress.com.ph/cdn/shop/articles/Aspin_dog_breed_600x600_crop_center.jpg?v=1727059098",
    description:
        "Bantay embodies the spirit of the Filipino Aspin: resilient, loving, and fiercely loyal. He enjoys sunshine, short runs, and curling up in a safe spot. Adaptable and affectionate, Bantay will warmly welcome a loving family.",
    rescueStory:
        "Beloved by neighbors for years until health issues required veterinary care; rescued and nurtured back to health, now ready for a forever home.",
  ),
];
