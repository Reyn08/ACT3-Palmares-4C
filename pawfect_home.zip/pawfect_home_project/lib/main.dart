import 'models/dog.dart';
import 'package:flutter/material.dart';
import 'views/browse_dogs.dart';
import 'views/about_us.dart';
import 'views/adoption_form.dart';
import 'views/layouts/layouts_menu.dart';

void main() {
  runApp(const PawfectHomesApp());
}

class PawfectHomesApp extends StatelessWidget {
  const PawfectHomesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pawfect Homes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFFEF8A49),
        scaffoldBackgroundColor: const Color(0xFFFDF6F0),
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepOrange).copyWith(secondary: const Color(0xFF8EC5C2)),
      ),
      routes: {
        '/': (context) => const HomeShell(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/adopt') {
          final dog = settings.arguments as Dog;
          return MaterialPageRoute(builder: (_) => AdoptionFormView(dog: dog));
        }
        return null;
      },
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _selectedIndex = 0;
  final pages = [
    const BrowseDogsView(),
    const AboutUsView(),
    const LayoutsMenu(),
    const ProfilePage(),
    const ChatPage(),
  ];

  void _onTap(int idx) => setState(() => _selectedIndex = idx);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(mainAxisSize: MainAxisSize.min, children: const [Text('🐾', style: TextStyle(fontSize:28)), SizedBox(width:8), Text('Pawfect Homes')]),
        centerTitle: true,
        backgroundColor: const Color(0xFFEF8A49),
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onTap,
        selectedItemColor: const Color(0xFFEF8A49),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.info), label: 'About'),
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_customize), label: 'Layouts'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble), label: 'Chat'),
        ],
      ),
    );
  }
}

// Activity #4: Create a profile card layout with Row (for profile picture + name) and Column (for details). (Profile page)
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [const Icon(Icons.person, color: Color(0xFFEF8A49)), const SizedBox(width: 8), Text('Profile', style: Theme.of(context).textTheme.titleLarge)]),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 2))]),
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const CircleAvatar(radius: 32, backgroundColor: Color(0xFFEF8A49), child: Text('AB', style: TextStyle(color: Colors.white))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Alex Brown', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          SizedBox(height: 4),
                          Text('Adopter • Loves hiking with dogs'),
                          SizedBox(height: 4),
                          Text('alex.brown@example.com'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Activity #9: Build a chat bubble UI using Container with padding, margin, and rounded borders. (Chat page)
class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final List<_Message> _messages = [
    const _Message(text: 'Hi! Is Bella good with kids?', isMine: false),
    const _Message(text: 'Yes! She’s wonderful with children.', isMine: true),
  ];
  final TextEditingController _controller = TextEditingController();

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add(_Message(text: text, isMine: true));
      _controller.clear();
      // Auto-reply (dummy)
      _messages.add(const _Message(text: 'Thanks! We will get back to you soon.', isMine: false));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Row(children: [const Icon(Icons.chat_bubble, color: Color(0xFFEF8A49)), const SizedBox(width: 8), Text('Shelter Chat', style: Theme.of(context).textTheme.titleLarge)]),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20))),
                padding: const EdgeInsets.all(16),
                child: ListView.builder(
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final m = _messages[index];
                    return Align(
                      alignment: m.isMine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: m.isMine ? const Color(0xFFEF8A49) : Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: const Radius.circular(16),
                            topRight: const Radius.circular(16),
                            bottomLeft: Radius.circular(m.isMine ? 16 : 0),
                            bottomRight: Radius.circular(m.isMine ? 0 : 16),
                          ),
                          boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
                        ),
                        child: Text(
                          m.text,
                          style: TextStyle(color: m.isMine ? Colors.white : Colors.black87),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              color: Colors.white,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        filled: true,
                        fillColor: const Color(0xFFF7F7F7),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                      ),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _send,
                    icon: const Icon(Icons.send),
                    color: const Color(0xFFEF8A49),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Message {
  final String text;
  final bool isMine;
  const _Message({required this.text, required this.isMine});
}
