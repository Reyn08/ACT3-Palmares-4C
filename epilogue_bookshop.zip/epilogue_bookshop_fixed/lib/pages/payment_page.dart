
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/order.dart';
import '../services/order_service.dart';
import 'package:intl/intl.dart';

class PaymentPage extends StatefulWidget {
  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  String _method = 'GCash';
  bool _agree = false;

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String,String>?;
    final title = args?['title'] ?? 'Unknown';
    final priceStr = args?['price'] ?? '₱0';
    final cover = args?['cover'] ?? '';
    // parse price like "₱299" to double
    double price = 0.0;
    try {
      price = double.parse(priceStr.replaceAll(RegExp(r'[^0-9.]'), ''));
    } catch (e) { price = 0.0; }

    return Scaffold(
      appBar: AppBar(title: Text('Payment')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (cover.isNotEmpty) Container(width:100, child: Image.network(cover, fit: BoxFit.cover)),
                  SizedBox(width:12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                    Text(title, style: Theme.of(context).textTheme.titleLarge),
                    SizedBox(height:6),
                    Text('₱' + price.toStringAsFixed(0), style: TextStyle(fontWeight: FontWeight.bold)),
                  ]))
                ],
              ),
              SizedBox(height:12),
              Text('Select payment method', style: Theme.of(context).textTheme.titleMedium),
              SizedBox(height:8),
              DropdownButtonFormField<String>(
                value: _method,
                items: ['GCash','Maya','Card','Cash on Delivery'].map((m)=> DropdownMenuItem(value:m, child: Text(m))).toList(),
                onChanged: (v)=> setState(()=> _method = v ?? 'GCash'),
              ),
              SizedBox(height:12),
              CheckboxListTile(title: Text('I confirm this purchase'), value: _agree, onChanged: (v)=> setState(()=> _agree = v ?? false)),
              SizedBox(height:12),
              ElevatedButton(
                onPressed: !_agree ? null : (){
                  final id = DateFormat('yyMMddHHmmss').format(DateTime.now());
                  final order = Order(id: '#'+id, title: title, method: _method, price: price, date: DateFormat.yMMMd().format(DateTime.now()));
                  Provider.of<OrderService>(context, listen:false).addOrder(order);
                  Navigator.pushNamed(context, '/success');
                },
                child: Text('Pay Now'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
