
import 'package:flutter/material.dart';

class FormsDemoPage extends StatefulWidget {
  @override
  _FormsDemoPageState createState() => _FormsDemoPageState();
}

class _FormsDemoPageState extends State<FormsDemoPage> {
  final _controller = TextEditingController();
  String _display = '';
  final _saved = <String>[];
  final _tf = TextEditingController();
  final _usernameFormKey = GlobalKey<FormState>();
  final _usernameCtrl = TextEditingController();
  bool _agree = false;
  bool _notif = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Forms Demo')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Form(
                    key: _usernameFormKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Username Form', style: Theme.of(context).textTheme.titleMedium),
                        SizedBox(height:8),
                        TextFormField(
                          controller: _usernameCtrl,
                          decoration: InputDecoration(labelText: 'Username'),
                          validator: (v)=> (v==null || v.trim().isEmpty) ? 'Please enter a username' : null,
                        ),
                        SizedBox(height:8),
                        Row(children:[
                          Expanded(child: ElevatedButton(onPressed: (){
                            if(_usernameFormKey.currentState?.validate() ?? false){
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Welcome, '+_usernameCtrl.text.trim())));
                            }
                          }, child: Text('Submit'))),
                        ])
                      ],
                    ),
                  ),
                ),
              ),
              Text('Controller demo'),
              TextField(controller: _controller, decoration: InputDecoration(labelText: 'Type something')),
              SizedBox(height:8),
              ElevatedButton(onPressed: (){ setState(()=> _display = _controller.text); }, child: Text('Show')),
              if(_display.isNotEmpty) Padding(padding: EdgeInsets.all(8), child: Text('You typed: '+_display)),
              Divider(),
              Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Mixed Inputs'),
                      TextField(decoration: InputDecoration(labelText: 'Favorite author')),
                      CheckboxListTile(
                        title: Text('Subscribe to author updates'),
                        value: _agree,
                        onChanged: (v)=> setState(()=> _agree = v ?? false),
                        controlAffinity: ListTileControlAffinity.leading,
                      ),
                      SwitchListTile(
                        title: Text('Enable notifications'),
                        value: _notif,
                        onChanged: (v)=> setState(()=> _notif = v),
                      ),
                    ],
                  ),
                ),
              ),
              Divider(),
              Text('Save inputs to local list'),
              TextField(controller: _tf, decoration: InputDecoration(labelText: 'Entry')),
              SizedBox(height:8),
              ElevatedButton(onPressed: (){ if(_tf.text.trim().isNotEmpty){ setState(()=> _saved.add(_tf.text.trim())); _tf.clear(); } }, child: Text('Save')),
              SizedBox(height:8),
              ..._saved.map((s)=> Card(child: Padding(padding: EdgeInsets.all(8), child: Text(s)))).toList(),
            ],
          ),
        ),
      ),
    );
  }
}
