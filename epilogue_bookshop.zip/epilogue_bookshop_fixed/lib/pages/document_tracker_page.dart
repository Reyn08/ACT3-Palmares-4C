
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/order_service.dart';

class DocumentTrackerPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final orders = Provider.of<OrderService>(context).orders;
    return Scaffold(
      appBar: AppBar(title: Text('Orders & Reservations')),
      body: SafeArea(
        child: orders.isEmpty ? Center(child: Padding(padding: EdgeInsets.all(12), child: Text('No orders yet'))) :
        ListView.builder(
          padding: EdgeInsets.all(12),
          itemCount: orders.length,
          itemBuilder: (context, i){
            final e = orders[i];
            return Card(
              child: ListTile(
                title: Text('${e.title} (${e.id})'),
                subtitle: Text('${e.method} • ₱${e.price.toStringAsFixed(0)} • ${e.date}'),
              ),
            );
          },
        ),
      ),
    );
  }
}
