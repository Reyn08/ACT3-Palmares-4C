
import 'package:flutter/material.dart';

class BookDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, String>?;
    final title = args?['title'] ?? 'Unknown';
    final author = args?['author'] ?? 'Author';
    final price = args?['price'] ?? '₱0';
    final cover = args?['cover'] ?? 'https://via.placeholder.com/150x220';

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 150,
                    height: 220,
                    child: Image.network(
                      cover, 
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          color: Colors.grey[300],
                          child: Icon(Icons.book, size: 50, color: Colors.grey[600]),
                        );
                      },
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Container(
                          color: Colors.grey[200],
                          child: Center(
                            child: CircularProgressIndicator(
                              value: loadingProgress.expectedTotalBytes != null
                                  ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                  : null,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title, 
                          style: Theme.of(context).textTheme.titleLarge,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 6),
                        Text(
                          author,
                          style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 6),
                        Text(
                          price, 
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Color(0xFF6B4F4F),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              SizedBox(height: 12),
              Text('Description', style: Theme.of(context).textTheme.titleMedium),
              SizedBox(height: 6),
              Text(
                args?['description'] ?? 'No description available.',
                style: TextStyle(fontSize: 16, height: 1.5),
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/payment', arguments: args), child: Text('Buy'))),
                  SizedBox(width: 8),
                  Expanded(child: OutlinedButton(onPressed: () => Navigator.pushNamed(context, '/reserve'), child: Text('Reserve'))),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
