
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _usernameCtrl = TextEditingController();
  final TextEditingController _emailCtrl = TextEditingController();
  final TextEditingController _passwordCtrl = TextEditingController();
  final TextEditingController _confirmCtrl = TextEditingController();
  String _role = 'User';
  bool _subscribe = false;
  bool _dark = false;

  void _register() {
    if (_formKey.currentState?.validate() ?? false) {
      // Dummy registration - go to home
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Register')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Card(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Full Name'),
                      validator: (v) => (v==null || v.isEmpty) ? 'Enter your name' : null,
                      controller: _nameCtrl,
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Username'),
                      validator: (v) => (v==null || v.isEmpty) ? 'Enter a username' : null,
                      controller: _usernameCtrl,
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Email'),
                      validator: (v) => (v==null || !v.contains('@')) ? 'Enter valid email' : null,
                      controller: _emailCtrl,
                    ),
                    SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: _role,
                      items: ['User','Admin'].map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
                      onChanged: (v) => setState(()=> _role = v ?? 'User'),
                      decoration: InputDecoration(labelText: 'Role'),
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Password'),
                      obscureText: true,
                      validator: (v) => (v==null || v.length < 4) ? 'Password too short' : null,
                      controller: _passwordCtrl,
                    ),
                    SizedBox(height: 8),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Confirm Password'),
                      obscureText: true,
                      validator: (v) => (v == null || v != _passwordCtrl.text) ? 'Passwords do not match' : null,
                      controller: _confirmCtrl,
                    ),
                    SizedBox(height: 12),
                    CheckboxListTile(value: _subscribe, onChanged: (v)=> setState(()=> _subscribe = v ?? false), title: Text('Subscribe to newsletter')),
                    SwitchListTile(value: _dark, onChanged: (v)=> setState(()=> _dark = v), title: Text('Enable dark preview')),
                    SizedBox(height: 12),
                    ElevatedButton(onPressed: _register, child: Text('Register')),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
