
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/order.dart';
import '../services/order_service.dart';

class ReservationPage extends StatefulWidget {
  @override
  _ReservationPageState createState() => _ReservationPageState();
}

class _ReservationPageState extends State<ReservationPage> {
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String _method = 'GCash';
  bool _agree = false;

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(context: context, initialDate: now, firstDate: now, lastDate: now.add(Duration(days: 365)));
    if (d != null) setState(()=> _selectedDate = d);
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (t != null) setState(()=> _selectedTime = t);
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = _selectedDate == null ? 'No date' : DateFormat.yMMMd().format(_selectedDate!);
    final timeStr = _selectedTime == null ? 'No time' : _selectedTime!.format(context);

    return Scaffold(
      appBar: AppBar(title: Text('Reservation')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Column(
                    children: [
                      ListTile(title: Text('Selected Date'), subtitle: Text(dateStr)),
                      ListTile(title: Text('Selected Time'), subtitle: Text(timeStr)),
                    SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: _method,
                      items: ['GCash','Maya','Card','Cash on Reservation'].map((m)=> DropdownMenuItem(value:m, child: Text(m))).toList(),
                      onChanged: (v)=> setState(()=> _method = v ?? 'GCash'),
                      decoration: InputDecoration(labelText: 'Payment Method'),
                    ),
                    CheckboxListTile(
                      title: Text('I agree to reservation terms'),
                      value: _agree,
                      onChanged: (v)=> setState(()=> _agree = v ?? false),
                      controlAffinity: ListTileControlAffinity.leading,
                    ),
                      Row(
                        children: [
                          Expanded(child: ElevatedButton(onPressed: _pickDate, child: Text('Pick date'))),
                          SizedBox(width: 8),
                          Expanded(child: ElevatedButton(onPressed: _pickTime, child: Text('Pick time'))),
                        ],
                      ),
                      SizedBox(height: 8),
                    ElevatedButton(onPressed: !_agree ? null : (){
                        // create reservation order with zero price
                        final id = DateTime.now().millisecondsSinceEpoch.toString();
                      final order = Order(id: '#'+id, title: 'Reservation', method: _method, price: 0.0, date: DateFormat.yMMMd().format(DateTime.now()));
                        Provider.of<OrderService>(context, listen:false).addOrder(order);
                        Navigator.pushNamed(context, '/success');
                      }, child: Text('Confirm Reservation')),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
