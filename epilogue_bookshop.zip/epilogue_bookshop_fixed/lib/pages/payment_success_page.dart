
import 'package:flutter/material.dart';

class PaymentSuccessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Success')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, size: 80, color: Colors.green),
                SizedBox(height: 12),
                Text('Payment / Reservation Confirmed', style: Theme.of(context).textTheme.titleLarge),
                SizedBox(height: 8),
                Text('This is a dummy confirmation screen for the Epilogue Bookshop demo.'),
                SizedBox(height: 16),
                ElevatedButton(onPressed: () => Navigator.pushNamedAndRemoveUntil(context, '/home', (r)=>false), child: Text('Back to Home')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
