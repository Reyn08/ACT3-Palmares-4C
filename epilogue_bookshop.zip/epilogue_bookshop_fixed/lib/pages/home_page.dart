
import 'package:flutter/material.dart';
import '../models/book_data.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchResult = '';
  final List<String> _feedbacks = [];
  final _feedbackCtrl = TextEditingController();

  List<Map<String,String>> get books => epilogueBooks.where((b){
    final q = _searchCtrl.text.toLowerCase();
    if (q.isEmpty) return true;
    return (b['title']!.toLowerCase().contains(q) || b['author']!.toLowerCase().contains(q));
  }).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Epilogue - Browse'),
        actions: [
          IconButton(icon: Icon(Icons.history), onPressed: ()=> Navigator.pushNamed(context, '/tracker')),
          IconButton(icon: Icon(Icons.article), onPressed: ()=> Navigator.pushNamed(context, '/forms')),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(labelText: 'Search books or author', suffixIcon: IconButton(icon: Icon(Icons.search), onPressed: (){ setState(()=> _searchResult = _searchCtrl.text); })),
              ),
              if(_searchResult.isNotEmpty) Padding(padding: EdgeInsets.symmetric(vertical:8), child: Text('Search preview: "'+_searchResult+'"')),
              SizedBox(height: 12),
              Text('Featured Books', style: Theme.of(context).textTheme.titleLarge),
              SizedBox(height: 12),
              GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, 
                  childAspectRatio: 0.65, 
                  crossAxisSpacing: 8, 
                  mainAxisSpacing: 8
                ),
                itemCount: books.length,
                itemBuilder: (context, index){
                  final b = books[index];
                  return GestureDetector(
                    onTap: () => Navigator.pushNamed(context, '/book', arguments: b),
                    child: Card(
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 3,
                            child: Container(
                              width: double.infinity,
                              child: Image.network(
                                b['cover']!, 
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    color: Colors.grey[300],
                                    child: Icon(Icons.book, size: 50, color: Colors.grey[600]),
                                  );
                                },
                                loadingBuilder: (context, child, loadingProgress) {
                                  if (loadingProgress == null) return child;
                                  return Container(
                                    color: Colors.grey[200],
                                    child: Center(
                                      child: CircularProgressIndicator(
                                        value: loadingProgress.expectedTotalBytes != null
                                            ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                            : null,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Padding(
                              padding: EdgeInsets.all(8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    b['title']!, 
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    b['author']!,
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey[600],
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    b['price']!,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF6B4F4F),
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              SizedBox(height: 16),
              Text('Leave feedback', style: Theme.of(context).textTheme.titleMedium),
              TextField(controller: _feedbackCtrl, decoration: InputDecoration(labelText: 'Your feedback')),
              SizedBox(height:8),
              ElevatedButton(onPressed: (){
                if(_feedbackCtrl.text.trim().isNotEmpty){
                  setState(()=> _feedbacks.add(_feedbackCtrl.text.trim()));
                  _feedbackCtrl.clear();
                }
              }, child: Text('Submit')),
              SizedBox(height:12),
              ..._feedbacks.map((f)=> Card(child: Padding(padding: EdgeInsets.all(8), child: Text(f)))).toList()
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/reserve'),
        child: Icon(Icons.calendar_today),
        tooltip: 'Make a reservation',
      ),
    );
  }
}
