import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final controller = TextEditingController();
  bool agree = false;
  bool notif = true;
  String displayed = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profile")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(labelText:"Enter username"),
            ),
            ElevatedButton(onPressed: (){
              setState(()=>displayed=controller.text);
            }, child: Text("Save")),
            Text(displayed),
            CheckboxListTile(
              value: agree,
              onChanged: (v)=>setState(()=>agree=v!),
              title: Text("Agree to Terms"),
            ),
            SwitchListTile(
              value: notif,
              onChanged: (v)=>setState(()=>notif=v),
              title: Text("Notifications"),
            ),
          ],
        ),
      ),
    );
  }
}
