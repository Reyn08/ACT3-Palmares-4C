import 'package:flutter/material.dart';

class BookDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, String>?;
    final title = args?['title'] ?? 'Unknown';
    final author = args?['author'] ?? 'Author';
    final price = args?['price'] ?? '₱0';
    final cover = args?['cover'] ?? 'https://via.placeholder.com/150x220';
    final description = args?['description'] ?? 'No description available.';

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Image.network(
            cover,
            height: 250,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                height: 250,
                color: Colors.grey[300],
                child: Icon(Icons.book, size: 50, color: Colors.grey[600]),
              );
            },
            loadingBuilder: (context, child, loadingProgress) {
              if (loadingProgress == null) return child;
              return Container(
                height: 250,
                color: Colors.grey[200],
                child: Center(
                  child: CircularProgressIndicator(
                    value: loadingProgress.expectedTotalBytes != null
                        ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                        : null,
                  ),
                ),
              );
            },
          ),
          SizedBox(height: 16),
          Text(
            title,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            "by $author",
            style: TextStyle(color: Colors.grey[700]),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(height: 8),
          Text(
            price,
            style: TextStyle(fontSize: 18, color: Colors.brown[800]),
          ),
          SizedBox(height: 16),
          Text(
            description,
            style: TextStyle(fontSize: 16, height: 1.5),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/payment', arguments: args),
            child: Text("Buy"),
          ),
          SizedBox(height: 8),
          OutlinedButton(
            onPressed: () => Navigator.pushNamed(context, '/reserve'),
            child: Text("Reserve"),
          ),
        ],
      ),
    );
  }
}
