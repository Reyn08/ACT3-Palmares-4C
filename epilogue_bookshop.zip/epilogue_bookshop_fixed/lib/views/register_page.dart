import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  String role = 'User';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Register")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(decoration: InputDecoration(labelText: "Name")),
              TextFormField(decoration: InputDecoration(labelText: "Email")),
              TextFormField(decoration: InputDecoration(labelText: "Password"), obscureText: true),
              TextFormField(decoration: InputDecoration(labelText: "Confirm Password"), obscureText: true),
              DropdownButtonFormField<String>(
                value: role,
                items: ['Admin','User'].map((r)=>DropdownMenuItem(value:r, child: Text(r))).toList(),
                onChanged: (v)=>setState(()=>role=v!),
                decoration: InputDecoration(labelText: "Role"),
              ),
              SizedBox(height:20),
              ElevatedButton(onPressed: (){
                Navigator.pushReplacementNamed(context, '/home');
              }, child: Text("Register"))
            ],
          ),
        ),
      ),
    );
  }
}
