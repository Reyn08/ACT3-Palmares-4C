
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pages/login_page.dart';
import 'pages/register_page.dart';
import 'pages/home_page.dart';
import 'pages/book_detail_page.dart';
import 'pages/reservation_page.dart';
import 'pages/document_tracker_page.dart';
import 'pages/payment_success_page.dart';
import 'pages/payment_page.dart';
import 'pages/forms_demo_page.dart';
import 'services/order_service.dart';

void main() {
  runApp(EpilogueApp());
}

class EpilogueApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => OrderService(),
      child: MaterialApp(
        title: 'Epilogue Bookshop',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Color(0xFF6B4F4F), // soft brown seed
            primary: Color(0xFF6B4F4F), // soft brown
            secondary: Color(0xFFC3A995), // warm beige accent
            surface: Color(0xFFF6EFEA), // light paper background
          ),
          scaffoldBackgroundColor: Color(0xFFF6EFEA),
          appBarTheme: AppBarTheme(
            backgroundColor: Color(0xFF6B4F4F),
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          cardTheme: CardTheme(
            color: Colors.white,
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          inputDecorationTheme: InputDecorationTheme(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            filled: true,
            fillColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFFB08968), // gold-ish accent
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
          textTheme: Typography.blackCupertino.apply(
            bodyColor: Color(0xFF3E2723),
            displayColor: Color(0xFF3E2723),
          ),
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => LoginPage(),
          '/register': (context) => RegisterPage(),
          '/home': (context) => HomePage(),
          '/book': (context) => BookDetailPage(),
          '/reserve': (context) => ReservationPage(),
          '/tracker': (context) => DocumentTrackerPage(),
          '/success': (context) => PaymentSuccessPage(),
          '/payment': (context) => PaymentPage(),
          '/forms': (context) => FormsDemoPage(),
        },
      ),
    );
  }
}
