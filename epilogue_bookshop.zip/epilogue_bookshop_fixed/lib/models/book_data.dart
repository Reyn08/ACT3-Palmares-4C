final List<Map<String,String>> epilogueBooks = [
  {
    "title": "The Midnight Library",
    "author": "Matt Haig",
    "price": "₱450",
    "cover": "https://picsum.photos/id/1015/150/220",
    "description": "A beautiful, uplifting novel about a library that contains an infinite number of books, each one the story of another reality."
  },
  {
    "title": "The Seven Husbands of Evelyn Hugo",
    "author": "Taylor Jenkins Reid",
    "price": "₱520",
    "cover": "https://picsum.photos/id/1025/150/220",
    "description": "A captivating novel about a reclusive Hollywood icon who finally decides to tell her story."
  },
  {
    "title": "Project Hail Mary",
    "author": "Andy Weir",
    "price": "₱480",
    "cover": "https://picsum.photos/id/1016/150/220",
    "description": "A lone astronaut must save the earth from disaster in this incredible new science-based thriller."
  },
  {
    "title": "The Invisible Life of Addie LaRue",
    "author": "V.E. Schwab",
    "price": "₱460",
    "cover": "https://picsum.photos/id/1021/150/220",
    "description": "A life no one will remember. A story you will never forget."
  },
  {
    "title": "The Silent Patient",
    "author": "Alex Michaelides",
    "price": "₱420",
    "cover": "https://picsum.photos/id/1035/150/220",
    "description": "A woman refuses to speak after allegedly murdering her husband in this psychological thriller."
  },
  {
    "title": "Where the Crawdads Sing",
    "author": "Delia Owens",
    "price": "₱440",
    "cover": "https://picsum.photos/id/1041/150/220",
    "description": "A mystery and coming-of-age story set in the marshes of North Carolina."
  },
  {
    "title": "The Book Thief",
    "author": "Markus Zusak",
    "price": "₱380",
    "cover": "https://picsum.photos/id/1062/150/220",
    "description": "A story about a young girl in Nazi Germany who steals books and shares them with others."
  },
  {
    "title": "The Kite Runner",
    "author": "Khaled Hosseini",
    "price": "₱400",
    "cover": "https://picsum.photos/id/1074/150/220",
    "description": "A powerful story of friendship, betrayal, and redemption set in Afghanistan."
  },
  {
    "title": "The Alchemist",
    "author": "Paulo Coelho",
    "price": "₱350",
    "cover": "https://picsum.photos/id/1084/150/220",
    "description": "A philosophical novel about a young shepherd's journey to find his personal legend."
  },
  {
    "title": "The Great Gatsby",
    "author": "F. Scott Fitzgerald",
    "price": "₱320",
    "cover": "https://picsum.photos/id/109/150/220",
    "description": "A classic American novel about the Jazz Age and the American Dream."
  },
  {
    "title": "To Kill a Mockingbird",
    "author": "Harper Lee",
    "price": "₱360",
    "cover": "https://picsum.photos/id/110/150/220",
    "description": "A timeless story of racial injustice and childhood innocence in the American South."
  },
  {
    "title": "1984",
    "author": "George Orwell",
    "price": "₱340",
    "cover": "https://picsum.photos/id/111/150/220",
    "description": "A dystopian novel about totalitarianism and the power of language and thought control."
  },
  {
    "title": "Pride and Prejudice",
    "author": "Jane Austen",
    "price": "₱330",
    "cover": "https://picsum.photos/id/112/150/220",
    "description": "A romantic novel about Elizabeth Bennet and Mr. Darcy in Regency England."
  },
  {
    "title": "The Catcher in the Rye",
    "author": "J.D. Salinger",
    "price": "₱310",
    "cover": "https://picsum.photos/id/113/150/220",
    "description": "A coming-of-age story about teenage rebellion and alienation in 1950s America."
  },
  {
    "title": "The Lord of the Rings",
    "author": "J.R.R. Tolkien",
    "price": "₱600",
    "cover": "https://picsum.photos/id/114/150/220",
    "description": "An epic fantasy novel about the quest to destroy the One Ring and save Middle-earth."
  }
];