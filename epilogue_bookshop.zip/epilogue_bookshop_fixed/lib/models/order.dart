
class Order {
  final String id;
  final String title;
  final String method;
  final double price;
  final String date;

  Order({
    required this.id,
    required this.title,
    required this.method,
    required this.price,
    required this.date,
  });
}
