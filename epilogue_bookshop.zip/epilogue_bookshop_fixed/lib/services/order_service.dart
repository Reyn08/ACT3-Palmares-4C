
import 'package:flutter/material.dart';
import '../models/order.dart';

class OrderService extends ChangeNotifier {
  final List<Order> _orders = [];

  List<Order> get orders => List.unmodifiable(_orders);

  void addOrder(Order order) {
    _orders.add(order);
    notifyListeners();
  }

  void clear() {
    _orders.clear();
    notifyListeners();
  }
}
